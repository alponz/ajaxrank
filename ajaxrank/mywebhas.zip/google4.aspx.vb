﻿
Partial Class google4
    Inherits System.Web.UI.Page
    Dim captcha As Integer
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBoxURL.Enabled = False
        TextBoxBackground.Enabled = False
        TextBoxFont.Enabled = False
        ImageButtonFont.Visible = False
        ImageButtonBackground.Visible = False
        TextBox4.Enabled = False
        Button1.Visible = False
        FormView1.Visible = True
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        captcha = CInt(10000 * Rnd() + 1)
        If Not IsPostBack Then
            ImageCaptcha.ImageUrl = "Default2.aspx?teks=" & captcha
            CompareValidator1.ValueToCompare = captcha
        End If
    End Sub
End Class
