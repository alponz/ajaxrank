﻿
Partial Class test1
    Inherits System.Web.UI.Page

End Class
