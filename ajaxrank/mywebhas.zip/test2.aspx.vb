﻿
Partial Class test2
    Inherits System.Web.UI.Page

End Class
