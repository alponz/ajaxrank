﻿
Partial Class Welcome
    Inherits System.Web.UI.MasterPage
End Class

